﻿using System;

namespace WebApplication.Models
{
    public class Entitytest1
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
