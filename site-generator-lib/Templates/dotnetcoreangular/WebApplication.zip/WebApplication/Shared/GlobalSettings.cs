﻿namespace WebApplication.Shared
{
    public static class GlobalSettings
    {
        public static string ConnectionString { get => "Host=localhost;Database=postgres;Username=postgres;Password=postgres"; }
    }
}
