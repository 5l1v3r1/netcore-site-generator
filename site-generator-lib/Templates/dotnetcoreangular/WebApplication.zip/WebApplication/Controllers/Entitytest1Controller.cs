﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication.Database;
using WebApplication.Models;

namespace WebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Entitytest1Controller : ControllerBase
    {
        private readonly Entitytest1DbContext _context;

        public Entitytest1Controller(Entitytest1DbContext context)
        {
            _context = context;
        }

        // GET: api/Entitytest1
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Entitytest1>>> GetEntitytest1()
        {
            return await _context.Entitytest1.ToListAsync();
        }

        // GET: api/Entitytest1/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Entitytest1>> GetEntitytest1(Guid id)
        {
            var entitytest1 = await _context.Entitytest1.FindAsync(id);

            if (entitytest1 == null)
            {
                return NotFound();
            }

            return entitytest1;
        }

        // PUT: api/Entitytest1/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEntitytest1(Guid id, Entitytest1 entitytest1)
        {
            if (id != entitytest1.Id)
            {
                return BadRequest();
            }

            _context.Entry(entitytest1).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Entitytest1Exists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Entitytest1
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Entitytest1>> PostEntitytest1(Entitytest1 entitytest1)
        {
            _context.Entitytest1.Add(entitytest1);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEntitytest1", new { id = entitytest1.Id }, entitytest1);
        }

        // DELETE: api/Entitytest1/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Entitytest1>> DeleteEntitytest1(Guid id)
        {
            var entitytest1 = await _context.Entitytest1.FindAsync(id);
            if (entitytest1 == null)
            {
                return NotFound();
            }

            _context.Entitytest1.Remove(entitytest1);
            await _context.SaveChangesAsync();

            return entitytest1;
        }

        private bool Entitytest1Exists(Guid id)
        {
            return _context.Entitytest1.Any(e => e.Id == id);
        }
    }
}
