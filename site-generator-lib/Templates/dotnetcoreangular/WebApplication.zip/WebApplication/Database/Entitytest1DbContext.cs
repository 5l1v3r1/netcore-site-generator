﻿using Microsoft.EntityFrameworkCore;
using WebApplication.Shared;
using WebApplication.Models;

namespace WebApplication.Database
{
    public class Entitytest1DbContext : DbContext
    {
        public Entitytest1DbContext(DbContextOptions options)
        : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            => optionsBuilder.UseNpgsql(GlobalSettings.ConnectionString);
        public DbSet<Entitytest1> Entitytest1 { get; set; }
    }
}
